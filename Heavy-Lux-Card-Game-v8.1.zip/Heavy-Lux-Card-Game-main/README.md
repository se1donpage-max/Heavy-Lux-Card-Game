# Heavy Lux Card

Online Durak 36 cards, 1x1 live players, authoritative Socket.IO server.

## v8.1
- Atomic PostgreSQL stake reservation and settlement.
- Idempotent game settlement ledger.
- Game transaction journal.
- Persistent game snapshots and active-room recovery.
- Explicit TEST_MODE for local development.
- Production requires DATABASE_URL and TELEGRAM_BOT_TOKEN.

## Environment
- `PORT` — HTTP port (default 10000).
- `DATABASE_URL` — PostgreSQL connection string. Required in production.
- `TELEGRAM_BOT_TOKEN` — Telegram bot token. Required in production.
- `TEST_MODE=true` — enables test authentication outside production.
- `NODE_ENV=production` — enables production requirements.
- `ALLOWED_ORIGINS` — comma-separated allowed origins; `*` by default for development.
